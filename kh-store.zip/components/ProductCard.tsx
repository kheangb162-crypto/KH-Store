
import React from 'react';
import { Star, Plus, Eye } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (p: Product) => void;
  onViewDetails: (p: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onViewDetails }) => {
  return (
    <div className="group bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      <div className="relative overflow-hidden aspect-square bg-slate-50">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
          <button 
            onClick={() => onViewDetails(product)}
            className="bg-white p-3 rounded-full shadow-lg text-slate-700 hover:bg-indigo-600 hover:text-white transition-all"
          >
            <Eye size={20} />
          </button>
        </div>
        {product.featured && (
          <div className="absolute top-4 left-4 bg-indigo-600 text-white text-[10px] font-bold px-2 py-1 rounded-md uppercase tracking-wider">
            Featured
          </div>
        )}
      </div>
      <div className="p-4">
        <div className="flex items-center gap-1 text-amber-400 mb-2">
          <Star size={14} fill="currentColor" />
          <span className="text-xs font-semibold text-slate-500">{product.rating}</span>
        </div>
        <h3 className="font-bold text-slate-800 line-clamp-1 mb-1">{product.name}</h3>
        <p className="text-xs text-slate-500 line-clamp-2 mb-4 h-8">{product.description}</p>
        <div className="flex items-center justify-between">
          <span className="text-lg font-bold text-indigo-600">${product.price.toFixed(2)}</span>
          <button 
            onClick={() => onAddToCart(product)}
            className="flex items-center gap-1 bg-slate-900 text-white px-3 py-2 rounded-xl text-xs font-semibold hover:bg-indigo-700 transition-colors shadow-sm"
          >
            <Plus size={14} /> Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
