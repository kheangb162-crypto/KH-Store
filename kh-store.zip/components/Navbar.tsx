
import React from 'react';
import { ShoppingCart, Menu, Search, User } from 'lucide-react';
import { AppView } from '../types';

interface NavbarProps {
  currentView: AppView;
  setView: (view: AppView) => void;
  cartCount: number;
  onOpenCart: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentView, setView, cartCount, onOpenCart }) => {
  return (
    <nav className="sticky top-0 z-50 glass-effect w-full px-4 md:px-8 py-4 flex items-center justify-between shadow-sm">
      <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView(AppView.HOME)}>
        <div className="bg-indigo-600 p-2 rounded-lg text-white">
          <span className="font-bold text-xl tracking-tighter">KH</span>
        </div>
        <span className="font-bold text-xl hidden sm:block">Store</span>
      </div>

      <div className="hidden md:flex items-center gap-8">
        <button 
          onClick={() => setView(AppView.HOME)}
          className={`font-medium hover:text-indigo-600 transition-colors ${currentView === AppView.HOME ? 'text-indigo-600' : 'text-slate-600'}`}
        >
          Home
        </button>
        <button 
          onClick={() => setView(AppView.STORE)}
          className={`font-medium hover:text-indigo-600 transition-colors ${currentView === AppView.STORE ? 'text-indigo-600' : 'text-slate-600'}`}
        >
          Store
        </button>
        <button 
          onClick={() => setView(AppView.ABOUT)}
          className={`font-medium hover:text-indigo-600 transition-colors ${currentView === AppView.ABOUT ? 'text-indigo-600' : 'text-slate-600'}`}
        >
          About
        </button>
        <button 
          onClick={() => setView(AppView.SUPPORT)}
          className={`font-medium hover:text-indigo-600 transition-colors ${currentView === AppView.SUPPORT ? 'text-indigo-600' : 'text-slate-600'}`}
        >
          Support
        </button>
      </div>

      <div className="flex items-center gap-4">
        <div className="hidden sm:flex items-center bg-slate-100 rounded-full px-4 py-2 border focus-within:ring-2 ring-indigo-200 transition-all">
          <Search size={18} className="text-slate-400" />
          <input 
            type="text" 
            placeholder="Search products..." 
            className="bg-transparent border-none outline-none ml-2 text-sm w-32 focus:w-48 transition-all"
          />
        </div>
        <button 
          onClick={() => setView(AppView.PROFILE)}
          className={`p-2 hover:bg-slate-100 rounded-full transition-colors relative ${currentView === AppView.PROFILE ? 'text-indigo-600 bg-slate-100' : 'text-slate-600'}`}
        >
          <User size={22} />
        </button>
        <button 
          onClick={onOpenCart}
          className="p-2 text-slate-600 hover:bg-slate-100 rounded-full transition-colors relative"
        >
          <ShoppingCart size={22} />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-indigo-600 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full">
              {cartCount}
            </span>
          )}
        </button>
        <button className="md:hidden p-2 text-slate-600">
          <Menu size={22} />
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
