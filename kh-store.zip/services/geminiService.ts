import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants";

export class GeminiService {
  private ai: GoogleGenAI;
  private chat: Chat | null = null;

  constructor() {
    // Fixed: Initializing GoogleGenAI with named parameter and direct process.env.API_KEY usage
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async initChat() {
    this.chat = this.ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });
  }

  async sendMessage(message: string): Promise<string> {
    if (!this.chat) {
      await this.initChat();
    }
    
    try {
      const response: GenerateContentResponse = await this.chat!.sendMessage({ message });
      // Fixed: Using the .text property directly (it's a getter, not a method)
      return response.text || "I'm sorry, I couldn't process that request.";
    } catch (error) {
      console.error("Gemini Error:", error);
      return "I'm having a bit of trouble connecting to my brain. Please try again in a moment!";
    }
  }
}

export const geminiService = new GeminiService();