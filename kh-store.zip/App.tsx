
import React, { useState, useMemo, useEffect } from 'react';
import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import CartDrawer from './components/CartDrawer';
import AIShopAssistant from './components/AIShopAssistant';
import { PRODUCTS } from './constants';
import { Product, CartItem, AppView } from './types';
import { 
  ArrowRight, ChevronRight, Star, ShieldCheck, Truck, RotateCcw, 
  MapPin, Navigation, Mail, Phone, MessageSquare, History, 
  Package, Settings, LogOut, Info, Heart, User, CreditCard, 
  Bell, Shield, Trash2, CheckCircle2, Clock, Smartphone, Globe, Check, 
  Send, Sparkles, ShoppingBag, ExternalLink, Copy
} from 'lucide-react';

type ProfileTab = 'overview' | 'orders' | 'history' | 'settings';
type CheckoutStatus = 'idle' | 'processing' | 'success';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.HOME);
  const [activeProfileTab, setActiveProfileTab] = useState<ProfileTab>('overview');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('All Items');
  const [checkoutStatus, setCheckoutStatus] = useState<CheckoutStatus>('idle');
  const [orderData, setOrderData] = useState<{orderId: string, items: string, total: string} | null>(null);
  const [copyFeedback, setCopyFeedback] = useState(false);
  
  // Newsletter state
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  // Location state
  const [location, setLocation] = useState<string | null>(localStorage.getItem('kh_store_location'));
  const [isLocating, setIsLocating] = useState(false);
  const [manualLocation, setManualLocation] = useState('');

  const cartCount = useMemo(() => cart.reduce((acc, item) => acc + item.quantity, 0), [cart]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(0, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const generateTelegramLink = () => {
    if (!orderData) return '#';
    const botId = "1793870335";
    const botHandle = "Ahbenzz_Bot"; // Updated to user's new bot handle
    
    const message = 
      `🛍️ *NEW ORDER FROM KH STORE*\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `🆔 *Order ID:* ${orderData.orderId}\n` +
      `📍 *Location:* ${location}\n` +
      `🤖 *Bot Ref:* ${botId}\n\n` +
      `📦 *Items List:*\n${orderData.items}\n\n` +
      `💰 *Total Amount:* ${orderData.total}\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `Please confirm my order!`;

    return `https://t.me/${botHandle}?text=${encodeURIComponent(message)}`;
  };

  const handleCheckout = () => {
    if (cart.length === 0) return;
    
    setCheckoutStatus('processing');
    
    const orderId = `KH-${Math.floor(100000 + Math.random() * 900000)}`;
    const itemsList = cart.map(item => `• ${item.name} (Qty: ${item.quantity})`).join('\n');
    const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const total = (subtotal + 2.00).toFixed(2);
    
    setOrderData({
      orderId,
      items: itemsList,
      total: `$${total}`
    });
    
    setTimeout(() => {
      setCheckoutStatus('success');
    }, 1800);
  };

  const finalizeOrder = () => {
    setCart([]);
    setCheckoutStatus('idle');
    setIsCartOpen(false);
    setView(AppView.HOME);
    window.scrollTo(0, 0);
  };

  const copyOrderId = () => {
    if (orderData) {
      navigator.clipboard.writeText(orderData.orderId);
      setCopyFeedback(true);
      setTimeout(() => setCopyFeedback(false), 2000);
    }
  };

  const viewDetails = (product: Product) => {
    setSelectedProduct(product);
    setView(AppView.DETAILS);
    window.scrollTo(0, 0);
  };

  const navigateToStoreWithFilter = (category: string) => {
    setSelectedCategory(category);
    setView(AppView.STORE);
    window.scrollTo(0, 0);
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim() && email.includes('@')) {
      setIsSubscribed(true);
      setTimeout(() => setIsSubscribed(false), 5000);
      setEmail('');
    }
  };

  const handleSetLocation = (loc: string) => {
    const cleanLoc = loc.trim();
    if (cleanLoc) {
      setLocation(cleanLoc);
      localStorage.setItem('kh_store_location', cleanLoc);
    }
  };

  const detectLocation = () => {
    setIsLocating(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coords = `${position.coords.latitude.toFixed(2)}, ${position.coords.longitude.toFixed(2)}`;
          handleSetLocation(`Nearby ${coords}`);
          setIsLocating(false);
        },
        (error) => {
          console.error("Error getting location:", error);
          alert("Could not detect location. Please enter it manually.");
          setIsLocating(false);
        }
      );
    } else {
      alert("Geolocation is not supported by your browser.");
      setIsLocating(false);
    }
  };

  const featuredProducts = useMemo(() => PRODUCTS.filter(p => p.featured), []);

  const filteredProducts = useMemo(() => {
    if (selectedCategory === 'All Items') return PRODUCTS;
    if (selectedCategory === 'Featured') return PRODUCTS.filter(p => p.featured);
    return PRODUCTS.filter(p => p.category === selectedCategory);
  }, [selectedCategory]);

  if (!location) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900 px-4">
        <div className="absolute inset-0 z-0 opacity-30">
          <img 
            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=2000" 
            className="w-full h-full object-cover"
            alt="Store background"
          />
          <div className="absolute inset-0 bg-indigo-900/40 mix-blend-multiply"></div>
        </div>

        <div className="relative z-10 w-full max-w-md bg-white rounded-[2.5rem] p-8 md:p-12 shadow-2xl animate-in fade-in zoom-in-95 duration-500">
          <div className="flex flex-col items-center text-center">
            <div className="bg-indigo-600 p-4 rounded-3xl text-white mb-6 shadow-lg shadow-indigo-200">
              <MapPin size={32} />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-3 tracking-tight">Welcome to KH Store</h1>
            <p className="text-slate-500 mb-8 leading-relaxed">
              To provide you with the best shopping experience and accurate shipping estimates, please set your location.
            </p>

            <div className="w-full space-y-4">
              <div className="relative">
                <input 
                  type="text" 
                  value={manualLocation}
                  onChange={(e) => setManualLocation(e.target.value)}
                  placeholder="Enter your city or zip code"
                  className="w-full px-6 py-4 rounded-2xl bg-slate-100 border-none outline-none focus:ring-2 ring-indigo-500 text-slate-900 font-medium transition-all"
                  onKeyDown={(e) => e.key === 'Enter' && handleSetLocation(manualLocation)}
                />
              </div>

              <button 
                onClick={() => handleSetLocation(manualLocation)}
                disabled={!manualLocation.trim()}
                className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold text-lg hover:bg-indigo-600 transition-all disabled:opacity-50 disabled:hover:bg-slate-900"
              >
                Set Location
              </button>

              <div className="flex items-center gap-4 py-2">
                <div className="h-px bg-slate-200 flex-1"></div>
                <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">or</span>
                <div className="h-px bg-slate-200 flex-1"></div>
              </div>

              <button 
                onClick={detectLocation}
                disabled={isLocating}
                className="w-full bg-indigo-50 text-indigo-600 py-4 rounded-2xl font-bold text-lg hover:bg-indigo-100 transition-all flex items-center justify-center gap-2"
              >
                {isLocating ? (
                  <div className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <Navigation size={20} />
                )}
                {isLocating ? 'Detecting...' : 'Use Current Location'}
              </button>
            </div>

            <p className="mt-8 text-[10px] text-slate-400 uppercase tracking-widest font-bold">
              Secure & Private • Flat $2 Shipping
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {checkoutStatus === 'processing' && (
        <div className="fixed inset-0 z-[200] bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-6 text-center">
          <div className="max-w-sm w-full bg-white rounded-[2.5rem] p-12 shadow-2xl flex flex-col items-center">
            <div className="relative w-24 h-24 mb-8">
              <div className="absolute inset-0 border-4 border-indigo-100 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center text-indigo-600">
                <Package size={32} className="animate-pulse" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mb-4 tracking-tight">Syncing with KH Bot</h2>
            <p className="text-slate-500 text-sm leading-relaxed">
              Verifying your secure order and preparing @Ahbenzz_Bot...
            </p>
          </div>
        </div>
      )}

      {checkoutStatus === 'success' && (
        <div className="fixed inset-0 z-[200] bg-indigo-600/95 backdrop-blur-xl flex items-center justify-center p-6 text-center animate-in fade-in duration-500">
          <div className="max-w-lg w-full bg-white rounded-[3rem] p-8 md:p-12 shadow-2xl flex flex-col items-center animate-in zoom-in-95 duration-500 delay-200 overflow-hidden relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-full -mr-16 -mt-16 blur-2xl"></div>
            
            <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-6 shadow-inner relative z-10">
              <Check size={40} className="animate-in slide-in-from-bottom-2 duration-700" />
            </div>
            
            <h2 className="text-3xl font-black text-slate-900 mb-2 relative z-10">Order Ready</h2>
            <p className="text-slate-500 text-sm mb-6 leading-relaxed relative z-10">
              Your order is prepared. Click below to send it to <span className="text-indigo-600 font-bold">@Ahbenzz_Bot</span>.
            </p>
            
            <div className="bg-slate-50 rounded-[2rem] p-6 w-full mb-8 border border-slate-100 text-left relative z-10">
               <div className="flex items-center justify-between mb-4">
                 <div className="flex items-center gap-3">
                    <div className="bg-indigo-600 p-2.5 rounded-xl text-white shadow-lg shadow-indigo-200"><Sparkles size={16} /></div>
                    <div>
                      <p className="font-bold text-sm">Ahbenzz Bot</p>
                      <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">ID: 1793870335</p>
                    </div>
                 </div>
                 <button 
                  onClick={copyOrderId}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-bold transition-all ${copyFeedback ? 'bg-emerald-500 text-white' : 'bg-white text-slate-500 hover:bg-slate-100 shadow-sm'}`}
                 >
                   {copyFeedback ? <Check size={12} /> : <Copy size={12} />}
                   {copyFeedback ? 'Copied' : orderData?.orderId}
                 </button>
               </div>
               
               <div className="space-y-3">
                  <div className="h-px bg-slate-200 w-full"></div>
                  <div className="max-h-24 overflow-y-auto pr-2 custom-scrollbar">
                    <p className="text-xs text-slate-600 font-medium whitespace-pre-line">{orderData?.items}</p>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                    <span className="text-[10px] font-black uppercase text-slate-400">Final Price</span>
                    <span className="text-lg font-black text-indigo-600">{orderData?.total}</span>
                  </div>
               </div>
            </div>

            <div className="flex flex-col gap-3 w-full relative z-10">
              <a 
                href={generateTelegramLink()}
                target="_blank"
                rel="noopener noreferrer"
                onClick={finalizeOrder}
                className="w-full bg-[#229ED9] text-white py-4 rounded-2xl font-bold hover:brightness-110 transition-all flex items-center justify-center gap-2 shadow-lg shadow-sky-100"
              >
                Send to Ahbenzz Bot <ExternalLink size={18} />
              </a>
              <button 
                onClick={finalizeOrder}
                className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
              >
                Done / Back Home
              </button>
            </div>
          </div>
        </div>
      )}

      <Navbar 
        currentView={view} 
        setView={setView} 
        cartCount={cartCount} 
        onOpenCart={() => setIsCartOpen(true)} 
      />

      <main>
        {view === AppView.HOME && (
          <>
            <section className="relative h-[80vh] overflow-hidden flex items-center px-4 md:px-12 bg-slate-900 text-white">
              <div className="absolute inset-0 z-0 opacity-40">
                <img 
                  src="https://images.unsplash.com/photo-1593642702821-c8da6771f0c6?auto=format&fit=crop&q=80&w=2000" 
                  alt="Modern Tech" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-slate-900 to-transparent"></div>
              </div>
              
              <div className="relative z-10 max-w-2xl animate-in fade-in slide-in-from-left-8 duration-700">
                <div className="flex items-center gap-2 mb-6">
                   <span className="inline-block bg-indigo-600/30 text-indigo-400 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest">
                    NEW ARRIVALS 2024
                  </span>
                  <div className="flex items-center gap-1 text-slate-400 text-xs font-medium">
                    <MapPin size={12} />
                    <span>Delivering to: {location}</span>
                  </div>
                </div>
                <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
                  Design for the <span className="text-indigo-500">Digital</span> Age.
                </h1>
                <p className="text-lg md:text-xl text-slate-300 mb-10 max-w-lg">
                  Curated premium electronics and lifestyle products that blend form and function perfectly.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <button 
                    onClick={() => setView(AppView.STORE)}
                    className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 group"
                  >
                    Shop Collection <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                  </button>
                  <button 
                    onClick={() => setView(AppView.ABOUT)}
                    className="bg-white/10 backdrop-blur-md text-white border border-white/20 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-white/20 transition-all"
                  >
                    Explore Trends
                  </button>
                </div>
              </div>
            </section>

            <section className="py-16 bg-slate-50 px-4 md:px-12">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-start gap-4">
                  <div className="bg-indigo-50 p-3 rounded-2xl text-indigo-600"><Truck size={24} /></div>
                  <div>
                    <h4 className="font-bold text-slate-800">Fast Shipping</h4>
                    <p className="text-xs text-slate-500 mt-1">Flat rate $2.00 worldwide</p>
                  </div>
                </div>
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-start gap-4">
                  <div className="bg-emerald-50 p-3 rounded-2xl text-emerald-600"><ShieldCheck size={24} /></div>
                  <div>
                    <h4 className="font-bold text-slate-800">Secure Payment</h4>
                    <p className="text-xs text-slate-500 mt-1">100% encrypted checkout</p>
                  </div>
                </div>
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-start gap-4">
                  <div className="bg-rose-50 p-3 rounded-2xl text-rose-600"><RotateCcw size={24} /></div>
                  <div>
                    <h4 className="font-bold text-slate-800">Easy Returns</h4>
                    <p className="text-xs text-slate-500 mt-1">30-day money back guarantee</p>
                  </div>
                </div>
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-start gap-4">
                  <div className="bg-amber-50 p-3 rounded-2xl text-amber-600"><Star size={24} /></div>
                  <div>
                    <h4 className="font-bold text-slate-800">Best Quality</h4>
                    <p className="text-xs text-slate-500 mt-1">Curated premium selection</p>
                  </div>
                </div>
              </div>
            </section>

            <section className="py-20 px-4 md:px-12">
              <div className="flex items-end justify-between mb-12">
                <div>
                  <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Featured Excellence</h2>
                  <p className="text-slate-500 max-w-xl">Hand-picked by our editors for their exceptional design and utility.</p>
                </div>
                <button 
                  onClick={() => setView(AppView.STORE)}
                  className="text-indigo-600 font-bold flex items-center gap-1 hover:gap-2 transition-all"
                >
                  View All Products <ChevronRight size={20} />
                </button>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {featuredProducts.map(product => (
                  <ProductCard 
                    key={product.id} 
                    product={product} 
                    onAddToCart={addToCart} 
                    onViewDetails={viewDetails}
                  />
                ))}
              </div>
            </section>
          </>
        )}

        {view === AppView.STORE && (
          <section className="py-12 px-4 md:px-12 bg-slate-50 min-h-screen">
            <div className="mb-12">
              <div className="flex justify-between items-center">
                <h2 className="text-3xl font-bold text-slate-900">Explore Catalog</h2>
                <button 
                  onClick={() => setLocation(null)}
                  className="text-xs text-slate-400 hover:text-indigo-600 flex items-center gap-1 transition-colors"
                >
                  <MapPin size={12} /> {location} (Change)
                </button>
              </div>
              <div className="flex flex-wrap gap-2 mt-6">
                {['All Items', 'Electronics', 'Lifestyle', 'Accessories', 'Apparel', 'Featured'].map(cat => (
                  <button 
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-6 py-2 rounded-full border text-sm font-medium transition-all ${selectedCategory === cat ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-600 hover:text-indigo-600'}`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {filteredProducts.map(product => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  onAddToCart={addToCart} 
                  onViewDetails={viewDetails}
                />
              ))}
              {filteredProducts.length === 0 && (
                 <div className="col-span-full py-20 text-center">
                   <p className="text-slate-500">No products found for this selection.</p>
                 </div>
              )}
            </div>
          </section>
        )}

        {view === AppView.ABOUT && (
          <section className="py-12 px-4 md:px-12 animate-in fade-in duration-500">
            <div className="max-w-4xl mx-auto">
              <div className="relative h-96 rounded-[3rem] overflow-hidden mb-12">
                <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=1200" alt="Office" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-indigo-900/40 flex items-center justify-center">
                  <h1 className="text-5xl font-bold text-white text-center">Our Story</h1>
                </div>
              </div>
              
              <div className="space-y-8 text-slate-600 leading-relaxed text-lg">
                <p>
                  Founded in 2024, <strong>KH Store</strong> was born from a simple idea: that technology should be as beautiful as it is powerful. We believe that the objects we surround ourselves with every day—from the headphones we use to the desk organizers that hold our creative tools—should inspire us.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 my-12">
                  <div className="bg-slate-50 p-8 rounded-3xl border border-slate-100">
                    <div className="text-indigo-600 mb-4"><Info size={32} /></div>
                    <h3 className="text-xl font-bold text-slate-900 mb-2">Our Mission</h3>
                    <p className="text-sm">To curate and create premium digital lifestyle products that simplify complexity and elevate the everyday experience through thoughtful design.</p>
                  </div>
                  <div className="bg-slate-50 p-8 rounded-3xl border border-slate-100">
                    <div className="text-indigo-600 mb-4"><Heart size={32} /></div>
                    <h3 className="text-xl font-bold text-slate-900 mb-2">Our Values</h3>
                    <p className="text-sm">Quality without compromise, aesthetic minimalism, and a commitment to customer satisfaction. We ship fast ($2 flat!) and care deeply.</p>
                  </div>
                </div>
                <p>
                  Based in Silicon Valley but serving the world, our team of designers and tech enthusiasts hand-picks every item in our catalog. We don't just sell products; we sell pieces of a modern, well-designed life.
                </p>
              </div>
            </div>
          </section>
        )}

        {view === AppView.SUPPORT && (
          <section className="py-12 px-4 md:px-12 animate-in fade-in duration-500">
            <div className="max-w-5xl mx-auto">
              <div className="text-center mb-16">
                <h1 className="text-4xl font-bold text-slate-900 mb-4">How can we help?</h1>
                <p className="text-slate-500">Find answers to common questions or reach out to our support team.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
                <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-sm text-center">
                  <div className="bg-indigo-50 w-12 h-12 rounded-2xl flex items-center justify-center text-indigo-600 mx-auto mb-4"><Mail size={24} /></div>
                  <h3 className="font-bold mb-1">Email Us</h3>
                  <p className="text-xs text-slate-500 mb-4">kheangb162@gmail.com</p>
                  <a href="mailto:kheangb162@gmail.com" className="text-indigo-600 text-sm font-bold">Send Message</a>
                </div>
                <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-sm text-center">
                  <div className="bg-emerald-50 w-12 h-12 rounded-2xl flex items-center justify-center text-emerald-600 mx-auto mb-4"><Phone size={24} /></div>
                  <h3 className="font-bold mb-1">Call Us</h3>
                  <p className="text-xs text-slate-500 mb-4">Mon-Fri, 9am - 6pm EST</p>
                  <a href="tel:+855889664205" className="text-emerald-600 text-sm font-bold">+855889664205</a>
                </div>
                <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-sm text-center">
                  <div className="bg-amber-50 w-12 h-12 rounded-2xl flex items-center justify-center text-amber-600 mx-auto mb-4"><MessageSquare size={24} /></div>
                  <h3 className="font-bold mb-1">Live Chat</h3>
                  <p className="text-xs text-slate-500 mb-4">Chat with our AI Assistant</p>
                  <button onClick={() => setView(AppView.STORE)} className="text-amber-600 text-sm font-bold">Open Assistant</button>
                </div>
              </div>

              <div className="bg-slate-50 rounded-[3rem] p-8 md:p-12" id="faq-section">
                <h2 className="text-2xl font-bold mb-8">Frequently Asked Questions</h2>
                <div className="space-y-6">
                  {[
                    { q: "What is your shipping policy?", a: "We offer fast shipping worldwide for a flat fee of $2.00 regardless of the order size." },
                    { q: "How do I track my order?", a: "Once your order ships, you'll receive an email with a tracking number and a link to our tracking portal." },
                    { q: "What is your return policy?", a: "We offer a 30-day money-back guarantee. If you're not satisfied, return it within 30 days for a full refund." },
                    { q: "Do you offer international shipping?", a: "Yes! We ship to over 50 countries globally with the same flat $2.00 fee." }
                  ].map((faq, i) => (
                    <div key={i} className="bg-white p-6 rounded-2xl shadow-sm">
                      <h4 className="font-bold text-slate-900 mb-2">{faq.q}</h4>
                      <p className="text-slate-500 text-sm">{faq.a}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {view === AppView.PROFILE && (
          <section className="py-12 px-4 md:px-12 animate-in fade-in duration-500">
            <div className="max-w-6xl mx-auto">
              <div className="flex flex-col md:flex-row gap-8">
                <aside className="w-full md:w-64 space-y-2">
                  <button 
                    onClick={() => setActiveProfileTab('overview')}
                    className={`w-full text-left px-6 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${activeProfileTab === 'overview' ? 'bg-indigo-600 text-white shadow-lg' : 'hover:bg-slate-100 text-slate-600'}`}
                  >
                    <User size={18} /> Account Overview
                  </button>
                  <button 
                    onClick={() => setActiveProfileTab('orders')}
                    className={`w-full text-left px-6 py-3 rounded-xl font-medium flex items-center gap-3 transition-all ${activeProfileTab === 'orders' ? 'bg-indigo-600 text-white shadow-lg font-bold' : 'hover:bg-slate-100 text-slate-600'}`}
                  >
                    <Package size={18} /> My Orders
                  </button>
                  <button 
                    onClick={() => setActiveProfileTab('history')}
                    className={`w-full text-left px-6 py-3 rounded-xl font-medium flex items-center gap-3 transition-all ${activeProfileTab === 'history' ? 'bg-indigo-600 text-white shadow-lg font-bold' : 'hover:bg-slate-100 text-slate-600'}`}
                  >
                    <History size={18} /> Order History
                  </button>
                  <button 
                    onClick={() => setActiveProfileTab('settings')}
                    className={`w-full text-left px-6 py-3 rounded-xl font-medium flex items-center gap-3 transition-all ${activeProfileTab === 'settings' ? 'bg-indigo-600 text-white shadow-lg font-bold' : 'hover:bg-slate-100 text-slate-600'}`}
                  >
                    <Settings size={18} /> Settings
                  </button>
                  <div className="pt-4 mt-4 border-t border-slate-100">
                    <button className="w-full text-left px-6 py-3 rounded-xl hover:bg-rose-50 text-rose-600 font-medium flex items-center gap-3">
                      <LogOut size={18} /> Logout
                    </button>
                  </div>
                </aside>

                <div className="flex-1">
                  <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white flex items-center gap-6 mb-8 shadow-2xl overflow-hidden relative group">
                    <div className="absolute -right-12 -top-12 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl group-hover:bg-indigo-500/20 transition-all duration-700"></div>
                    <div className="relative z-10 w-20 h-20 rounded-full bg-indigo-600 flex items-center justify-center text-3xl font-bold uppercase ring-4 ring-white/10">
                      KB
                    </div>
                    <div className="relative z-10">
                      <h1 className="text-2xl font-bold">Kheang benzz</h1>
                      <p className="opacity-70 text-sm">Member since January 2024 • Gold Tier</p>
                      <div className="mt-2 flex items-center gap-2 bg-white/10 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider">
                        <MapPin size={10} /> {location}
                        <button onClick={() => setLocation(null)} className="underline ml-2 hover:text-indigo-400">Change</button>
                      </div>
                    </div>
                  </div>

                  <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
                    {activeProfileTab === 'overview' && (
                      <div className="space-y-8">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-sm flex flex-col justify-center items-center text-center">
                            <span className="text-slate-400 text-[10px] uppercase font-black mb-1">KH Points</span>
                            <span className="text-4xl font-black text-indigo-600 leading-none">2,450</span>
                            <button className="mt-4 text-xs font-bold text-indigo-500 hover:underline">Redeem Now</button>
                          </div>
                          <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-sm flex flex-col justify-center items-center text-center">
                            <span className="text-slate-400 text-[10px] uppercase font-black mb-1">Total Orders</span>
                            <span className="text-4xl font-black text-slate-800 leading-none">12</span>
                            <span className="mt-4 text-[10px] text-slate-400 font-bold uppercase">2 Pending</span>
                          </div>
                          <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-sm flex flex-col justify-center items-center text-center">
                            <span className="text-slate-400 text-[10px] uppercase font-black mb-1">Saved Items</span>
                            <span className="text-4xl font-black text-rose-500 leading-none">8</span>
                            <button className="mt-4 text-xs font-bold text-rose-500 hover:underline">View Wishlist</button>
                          </div>
                        </div>

                        <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm">
                          <h3 className="font-bold text-lg mb-6 flex items-center gap-2"><CreditCard size={20} className="text-indigo-500" /> Default Payment Method</h3>
                          <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                             <div className="w-12 h-8 bg-slate-800 rounded flex items-center justify-center text-[10px] text-white font-bold italic tracking-tighter">VISA</div>
                             <div className="flex-1">
                               <p className="text-sm font-bold text-slate-800">Visa ending in •••• 4492</p>
                               <p className="text-xs text-slate-500 font-medium">Expires 12/26</p>
                             </div>
                             <button className="text-xs font-bold text-indigo-600 hover:underline">Edit</button>
                          </div>
                        </div>

                        <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm">
                          <h3 className="font-bold text-lg mb-6">Personal Details</h3>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-8 gap-x-12">
                            <div>
                              <label className="text-[10px] uppercase font-black text-slate-400 block mb-1">Full Name</label>
                              <p className="font-medium text-slate-900">Kheang benzz</p>
                            </div>
                            <div>
                              <label className="text-[10px] uppercase font-black text-slate-400 block mb-1">Email Address</label>
                              <p className="font-medium text-slate-900">kheang.benzz@example.com</p>
                            </div>
                            <div>
                              <label className="text-[10px] uppercase font-black text-slate-400 block mb-1">Phone</label>
                              <p className="font-medium text-slate-900">+855 889 664 205</p>
                            </div>
                            <div>
                              <label className="text-[10px] uppercase font-black text-slate-400 block mb-1">Delivery Address</label>
                              <p className="font-medium text-slate-900">{location || 'Not set'}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {activeProfileTab === 'orders' && (
                      <div className="space-y-6">
                        <div className="flex items-center justify-between mb-2">
                           <h3 className="font-bold text-lg">Active Orders</h3>
                           <span className="text-xs bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full font-bold uppercase tracking-widest">2 ITEMS SHIPPING</span>
                        </div>
                        
                        {[
                          { id: 'KH-29402', product: PRODUCTS[0], date: 'Oct 24, 2024', status: 'Processing', total: 301.99 },
                          { id: 'KH-29381', product: PRODUCTS[3], date: 'Oct 22, 2024', status: 'In Transit', total: 131.99 }
                        ].map(order => (
                          <div key={order.id} className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm hover:border-indigo-200 transition-all duration-300 group">
                            <div className="flex flex-col sm:flex-row gap-6">
                              <div className="w-24 h-24 bg-slate-50 rounded-2xl overflow-hidden flex-shrink-0 ring-1 ring-slate-100 group-hover:ring-indigo-200 transition-all">
                                <img src={order.product.image} alt="order item" className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                              </div>
                              <div className="flex-1">
                                <div className="flex justify-between items-start mb-2">
                                  <div>
                                    <h4 className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{order.product.name}</h4>
                                    <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Order #{order.id}</p>
                                  </div>
                                  <div className="text-right">
                                    <span className="text-lg font-black text-slate-900">${order.total.toFixed(2)}</span>
                                    <p className="text-[10px] text-slate-400 font-bold">{order.date}</p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2 mt-4">
                                  <div className={`w-2 h-2 rounded-full ${order.status === 'In Transit' ? 'bg-indigo-500 animate-pulse' : 'bg-amber-500'}`}></div>
                                  <span className={`text-xs font-bold uppercase tracking-widest ${order.status === 'In Transit' ? 'text-indigo-600' : 'text-amber-600'}`}>{order.status}</span>
                                  <span className="text-slate-300 mx-2">•</span>
                                  <button className="text-xs font-bold text-slate-500 hover:text-indigo-600 transition-colors">Track Shipment</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {activeProfileTab === 'history' && (
                      <div className="space-y-4">
                        <h3 className="font-bold text-lg mb-4">Past Purchases</h3>
                        <div className="bg-white border border-slate-100 rounded-3xl overflow-hidden shadow-sm">
                          <div className="overflow-x-auto">
                            <table className="w-full text-left">
                              <thead className="bg-slate-50 border-b border-slate-100">
                                <tr>
                                  <th className="px-6 py-4 text-[10px] uppercase font-black text-slate-400">Order ID</th>
                                  <th className="px-6 py-4 text-[10px] uppercase font-black text-slate-400">Items</th>
                                  <th className="px-6 py-4 text-[10px] uppercase font-black text-slate-400">Total</th>
                                  <th className="px-6 py-4 text-[10px] uppercase font-black text-slate-400">Status</th>
                                  <th className="px-6 py-4 text-[10px] uppercase font-black text-slate-400">Action</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-100">
                                {[
                                  { id: '#KH-28100', items: '2 items', total: '$342.00', date: 'Sept 12, 2024', status: 'Delivered' },
                                  { id: '#KH-27902', items: '1 item', total: '$85.00', date: 'Aug 29, 2024', status: 'Delivered' },
                                  { id: '#KH-27511', items: '3 items', total: '$1,200.00', date: 'July 15, 2024', status: 'Delivered' },
                                  { id: '#KH-26490', items: '1 item', total: '$45.00', date: 'June 02, 2024', status: 'Returned' },
                                ].map((row, i) => (
                                  <tr key={i} className="hover:bg-slate-50 transition-colors group">
                                    <td className="px-6 py-4">
                                      <p className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{row.id}</p>
                                      <p className="text-[10px] text-slate-400 font-bold">{row.date}</p>
                                    </td>
                                    <td className="px-6 py-4 text-sm font-medium text-slate-600">{row.items}</td>
                                    <td className="px-6 py-4 text-sm font-bold text-slate-900">{row.total}</td>
                                    <td className="px-6 py-4">
                                      <div className="flex items-center gap-1.5">
                                        {row.status === 'Delivered' ? <CheckCircle2 size={12} className="text-emerald-500" /> : <Clock size={12} className="text-rose-500" />}
                                        <span className={`text-[10px] font-black uppercase tracking-widest ${row.status === 'Delivered' ? 'text-emerald-600' : 'text-rose-600'}`}>{row.status}</span>
                                      </div>
                                    </td>
                                    <td className="px-6 py-4">
                                      <button className="text-[10px] font-black uppercase text-indigo-600 hover:text-indigo-800 transition-colors">Details</button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    )}

                    {activeProfileTab === 'settings' && (
                      <div className="space-y-8">
                        <div className="bg-white border border-slate-100 rounded-3xl p-8 shadow-sm">
                          <h3 className="font-bold text-lg mb-6 flex items-center gap-2"><Bell size={20} className="text-indigo-500" /> Notifications</h3>
                          <div className="space-y-6">
                            {[
                              { label: 'Order Updates', desc: 'Receive emails and SMS about your order status.', icon: <Smartphone size={16} /> },
                              { label: 'Marketing Communications', desc: 'Hear about our latest drops and exclusive point rewards.', icon: <Mail size={16} /> }
                            ].map((item, i) => (
                              <div key={i} className="flex items-center justify-between group">
                                <div className="flex gap-4">
                                  <div className="mt-1 text-slate-400 group-hover:text-indigo-500 transition-colors">{item.icon}</div>
                                  <div>
                                    <p className="font-bold text-slate-800 text-sm">{item.label}</p>
                                    <p className="text-xs text-slate-500">{item.desc}</p>
                                  </div>
                                </div>
                                <div className="w-10 h-5 bg-indigo-600 rounded-full relative cursor-pointer shadow-inner">
                                  <div className="absolute right-0.5 top-0.5 w-4 h-4 bg-white rounded-full transition-all"></div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {view === AppView.DETAILS && selectedProduct && (
          <section className="py-12 px-4 md:px-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <button 
              onClick={() => setView(AppView.STORE)}
              className="mb-8 text-slate-500 hover:text-indigo-600 flex items-center gap-2 font-medium"
            >
              <ArrowRight className="rotate-180" size={18} /> Back to Catalog
            </button>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="bg-slate-50 rounded-3xl overflow-hidden aspect-square flex items-center justify-center border border-slate-100 shadow-inner">
                <img 
                  src={selectedProduct.image} 
                  alt={selectedProduct.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex flex-col justify-center">
                <span className="text-indigo-600 font-bold text-sm tracking-widest uppercase mb-4">{selectedProduct.category}</span>
                <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">{selectedProduct.name}</h1>
                
                <div className="flex items-center gap-4 mb-8">
                  <div className="flex items-center gap-1 text-amber-400">
                    <Star fill="currentColor" size={20} />
                    <Star fill="currentColor" size={20} />
                    <Star fill="currentColor" size={20} />
                    <Star fill="currentColor" size={20} />
                    <Star fill="currentColor" size={20} />
                  </div>
                  <span className="text-slate-500 font-medium">{selectedProduct.rating} (120+ reviews)</span>
                </div>

                <p className="text-lg text-slate-600 mb-8 leading-relaxed">
                  {selectedProduct.description}
                  <br /><br />
                  Crafted with premium materials and engineered for those who demand excellence. 
                  Every KH product undergoes rigorous quality testing to ensure durability and performance.
                </p>

                <div className="flex items-center gap-8 mb-10">
                  <div className="text-3xl font-bold text-slate-900">${selectedProduct.price.toFixed(2)}</div>
                  <div className="text-sm text-green-600 font-bold flex items-center gap-1">
                    <div className="w-2 h-2 rounded-full bg-green-500"></div> In Stock
                  </div>
                  <div className="text-xs text-slate-400 bg-slate-100 px-3 py-1 rounded-full">+ $2.00 Shipping</div>
                </div>

                <div className="flex gap-4">
                  <button 
                    onClick={() => addToCart(selectedProduct)}
                    className="flex-1 bg-slate-900 text-white py-4 rounded-2xl font-bold text-lg hover:bg-indigo-600 transition-all shadow-xl hover:shadow-indigo-200"
                  >
                    Add to Shopping Cart
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}
      </main>

      <footer className="bg-slate-900 text-white py-20 px-4 md:px-12 mt-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div>
            <div className="flex items-center gap-2 mb-8">
              <div className="bg-indigo-600 p-2 rounded-lg text-white">
                <span className="font-bold text-xl tracking-tighter">KH</span>
              </div>
              <span className="font-bold text-xl">Store</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Redefining the digital lifestyle since 2024. Premium products, exceptional design, and intelligent service.
            </p>
          </div>
          <div>
            <h4 className="font-bold text-lg mb-8">Shop</h4>
            <ul className="space-y-4 text-slate-400">
              <li><button onClick={() => navigateToStoreWithFilter('All Items')} className="hover:text-indigo-400 transition-colors">All Products</button></li>
              <li><button onClick={() => navigateToStoreWithFilter('Featured')} className="hover:text-indigo-400 transition-colors">Featured</button></li>
              <li><button onClick={() => navigateToStoreWithFilter('Electronics')} className="hover:text-indigo-400 transition-colors">New Arrivals</button></li>
              <li><button onClick={() => navigateToStoreWithFilter('Apparel')} className="hover:text-indigo-400 transition-colors">Discounts</button></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-lg mb-8">Support</h4>
            <ul className="space-y-4 text-slate-400">
              <li><button onClick={() => { setView(AppView.SUPPORT); setTimeout(() => document.getElementById('faq-section')?.scrollIntoView({ behavior: 'smooth' }), 100); }} className="hover:text-indigo-400 transition-colors">Help Center</button></li>
              <li><button onClick={() => { setView(AppView.PROFILE); setActiveProfileTab('orders'); window.scrollTo(0,0); }} className="hover:text-indigo-400 transition-colors">Order Tracking</button></li>
              <li><button onClick={() => { setView(AppView.SUPPORT); window.scrollTo(0,0); }} className="hover:text-indigo-400 transition-colors">Shipping Policy</button></li>
              <li><button onClick={() => { setView(AppView.SUPPORT); window.scrollTo(0,0); }} className="hover:text-indigo-400 transition-colors">Contact Us</button></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-lg mb-8">Newsletter</h4>
            <p className="text-slate-400 text-sm mb-6">Stay updated with our latest releases and exclusive offers.</p>
            {isSubscribed ? (
               <div className="bg-indigo-600/20 border border-indigo-500/50 rounded-2xl p-4 flex items-center gap-3 text-indigo-400 animate-in zoom-in-95">
                 <div className="bg-indigo-500 rounded-full p-1 text-white">
                   <Check size={14} />
                 </div>
                 <span className="text-xs font-bold uppercase tracking-widest">Subscribed!</span>
               </div>
            ) : (
              <form onSubmit={handleNewsletterSubmit} className="flex gap-2">
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email" 
                  className="bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-sm flex-1 outline-none focus:ring-2 ring-indigo-500"
                  required
                />
                <button type="submit" className="bg-indigo-600 px-4 py-2 rounded-xl text-sm font-bold hover:bg-indigo-700 transition-colors">Join</button>
              </form>
            )}
          </div>
        </div>
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-500 text-sm">
          <p>© 2024 KH Store. All rights reserved.</p>
          <div className="flex gap-8">
            <button className="hover:text-white transition-colors">Privacy Policy</button>
            <button className="hover:text-white transition-colors">Terms of Service</button>
          </div>
        </div>
      </footer>

      <CartDrawer 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        items={cart}
        onUpdateQuantity={updateQuantity}
        onRemove={removeFromCart}
        onCheckout={handleCheckout}
      />

      <AIShopAssistant />
    </div>
  );
};

export default App;
