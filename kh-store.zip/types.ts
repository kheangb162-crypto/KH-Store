
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  rating: number;
  featured?: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export enum AppView {
  HOME = 'home',
  STORE = 'store',
  DETAILS = 'details',
  ABOUT = 'about',
  SUPPORT = 'support',
  PROFILE = 'profile'
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
