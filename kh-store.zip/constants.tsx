
import { Product } from './types';

export const PRODUCTS: Product[] = [
  // --- ELECTRONICS ---
  {
    id: '1',
    name: 'KH Ultra Wireless Headphones',
    description: 'Noise-canceling, premium sound with 40-hour battery life. Experience audio like never before with KH spatial sound technology.',
    price: 299.99,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=600',
    rating: 4.8,
    featured: true
  },
  {
    id: '3',
    name: 'KH Smart Home Hub',
    description: 'Control your entire home with one sleek interface. Compatible with over 2000 smart devices.',
    price: 129.99,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1558002038-1037906d9927?auto=format&fit=crop&q=80&w=600',
    rating: 4.5
  },
  {
    id: '6',
    name: 'Nebula Smart Projector',
    description: 'Portable 4K cinematic experience. Stream your favorite shows anywhere with built-in Wi-Fi.',
    price: 899.00,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1535016120720-40c646bebbfc?auto=format&fit=crop&q=80&w=600',
    rating: 4.9
  },
  {
    id: '7',
    name: 'KH Mechanical Pro Keyboard',
    description: 'Ultra-responsive mechanical switches with customizable RGB lighting and premium aluminum build.',
    price: 189.99,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?auto=format&fit=crop&q=80&w=600',
    rating: 4.8,
    featured: true
  },
  {
    id: '10',
    name: 'KH Precision Wireless Mouse',
    description: 'Ergonomic design with 24,000 DPI sensor and hyper-fast scrolling for maximum productivity.',
    price: 95.00,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?auto=format&fit=crop&q=80&w=600',
    rating: 4.9
  },
  {
    id: '11',
    name: 'KH 4K Curved Monitor',
    description: '34-inch ultrawide display with 144Hz refresh rate. Perfect for immersive gaming and creative workflows.',
    price: 549.99,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&q=80&w=600',
    rating: 4.7
  },
  {
    id: '19',
    name: 'KH Air-Lite Earbuds',
    description: 'True wireless earbuds with transparency mode and spatial audio. Sweat resistant and pocket-sized.',
    price: 149.00,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&q=80&w=600',
    rating: 4.6
  },

  // --- LIFESTYLE ---
  {
    id: '4',
    name: 'Eco-Craft Desk Organizer',
    description: 'Sustainably sourced bamboo desk organizer. Keep your workspace clean and beautiful.',
    price: 45.00,
    category: 'Lifestyle',
    image: 'https://images.unsplash.com/photo-1591129841117-3adfd313e34f?auto=format&fit=crop&q=80&w=600',
    rating: 4.7
  },
  {
    id: '8',
    name: 'KH Smart Thermal Mug',
    description: 'App-controlled temperature settings keep your drink perfect for up to 12 hours.',
    price: 75.00,
    category: 'Lifestyle',
    image: 'https://images.unsplash.com/photo-1517256011271-101ad9d4bbfa?auto=format&fit=crop&q=80&w=600',
    rating: 4.7
  },
  {
    id: '12',
    name: 'Minimalist Zen Lamp',
    description: 'Adjustable warm lighting with a sleek walnut base. Touch-sensitive controls and wireless phone charging built-in.',
    price: 120.00,
    category: 'Lifestyle',
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&q=80&w=600',
    rating: 4.6
  },
  {
    id: '13',
    name: 'PureAir Aroma Diffuser',
    description: 'Ultrasonic essential oil diffuser with ambient LED ring. Super quiet operation for better sleep and focus.',
    price: 55.00,
    category: 'Lifestyle',
    image: 'https://images.unsplash.com/photo-1614713706391-997274092d6e?auto=format&fit=crop&q=80&w=600',
    rating: 4.8
  },
  {
    id: '20',
    name: 'KH Ergonomic Standing Desk',
    description: 'Electric height-adjustable desk with memory presets and a smooth, scratch-resistant surface.',
    price: 499.00,
    category: 'Lifestyle',
    image: 'https://images.unsplash.com/photo-1595515106969-1ce29566ff1c?auto=format&fit=crop&q=80&w=600',
    rating: 4.9
  },
  {
    id: '21',
    name: 'Ceramic Smart Kettle',
    description: 'Precision temperature control for different tea types. Beautiful ceramic finish with auto-shutoff.',
    price: 89.00,
    category: 'Lifestyle',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&q=80&w=600',
    rating: 4.5
  },

  // --- ACCESSORIES ---
  {
    id: '2',
    name: 'Minimalist Titanium Watch',
    description: 'Sleek, lightweight, and durable. This titanium watch features a sapphire crystal face and automatic movement.',
    price: 450.00,
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=600',
    rating: 4.9,
    featured: true
  },
  {
    id: '9',
    name: 'KH Nomad Travel Backpack',
    description: 'Water-resistant, anti-theft design with integrated USB charging port and 16-inch laptop sleeve.',
    price: 110.00,
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&q=80&w=600',
    rating: 4.6
  },
  {
    id: '14',
    name: 'Full-Grain Leather Wallet',
    description: 'Handcrafted premium leather with RFID protection. Slim profile that holds up to 8 cards and cash.',
    price: 65.00,
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1627123430985-71d464a0b89a?auto=format&fit=crop&q=80&w=600',
    rating: 4.7
  },
  {
    id: '15',
    name: 'Pro Tech Pouch',
    description: 'Organize your cables, chargers, and small gear in this weather-resistant, padded pouch.',
    price: 35.00,
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1590247813693-5541d1c609fd?auto=format&fit=crop&q=80&w=600',
    rating: 4.5
  },
  {
    id: '22',
    name: 'Leather Laptop Sleeve',
    description: 'Slim fit sleeve for 14-inch laptops. Soft microfiber lining to prevent scratches and premium leather exterior.',
    price: 55.00,
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=600',
    rating: 4.8
  },

  // --- APPAREL ---
  {
    id: '5',
    name: 'KH Peak Performance Sneakers',
    description: 'Engineered for athletes. Responsive cushioning and breathable mesh for maximum comfort.',
    price: 160.00,
    category: 'Apparel',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=600',
    rating: 4.6
  },
  {
    id: '16',
    name: 'Essential Oversized Hoodie',
    description: 'Ultra-soft heavy fleece hoodie with a relaxed fit. Double-lined hood and reinforced stitching.',
    price: 85.00,
    category: 'Apparel',
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=600',
    rating: 4.8,
    featured: true
  },
  {
    id: '17',
    name: 'Core Seamless Tee',
    description: 'Moisture-wicking, seamless construction for zero irritation during workouts or daily wear.',
    price: 45.00,
    category: 'Apparel',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&q=80&w=600',
    rating: 4.5
  },
  {
    id: '18',
    name: 'Eco-Cotton Curved Cap',
    description: 'Classic 6-panel cap made from 100% organic cotton. Adjustable strap with brass buckle.',
    price: 28.00,
    category: 'Apparel',
    image: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&q=80&w=600',
    rating: 4.4
  },
  {
    id: '23',
    name: 'KH Tech-Wear Jacket',
    description: 'Windproof and water-resistant technical jacket with multiple hidden pockets and reflective detailing.',
    price: 210.00,
    category: 'Apparel',
    image: 'https://images.unsplash.com/photo-1591047139829-d91aec06adce?auto=format&fit=crop&q=80&w=600',
    rating: 4.9,
    featured: true
  },
  {
    id: '24',
    name: 'Merino Wool Joggers',
    description: 'Temperature-regulating joggers perfect for lounging or travel. Sustainable and incredibly soft.',
    price: 120.00,
    category: 'Apparel',
    image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80&w=600',
    rating: 4.7
  }
];

export const SYSTEM_INSTRUCTION = `
You are KH Assistant, the expert AI shopping concierge for KH Store.
KH Store is a premium lifestyle and electronics shop.

CRITICAL POLICY UPDATE:
- Fast shipping is available for a flat fee of $2.00 for all orders.

Our catalog is divided into four main categories: Electronics, Lifestyle, Accessories, and Apparel.

Our full catalog includes:
${PRODUCTS.map(p => `- [${p.category}] ${p.name} ($${p.price}): ${p.description}`).join('\n')}

Guidelines:
1. Be helpful, professional, and friendly.
2. If a user asks about shipping, always mention the flat $2.00 fee.
3. If a user asks for something we don't have, suggest the closest alternative from our catalog.
4. Keep responses concise but informative.
5. Use markdown for better formatting.
`;
